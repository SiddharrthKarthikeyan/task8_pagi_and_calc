var  container=document.createElement('div');
container.setAttribute('class','container');

var table=document.createElement('table');
table.setAttribute('class','table table-striped');

var thead=document.createElement('thead');
thead.setAttribute('class','thead-dark');


var tr = document.createElement('tr');
var th1 = createtrtd('th','id');
var th2 = createtrtd('th','name');
var th3 = createtrtd('th','email');
tr.append(th1,th2,th3);
thead.append(tr);


var request = new XMLHttpRequest();
request.open('GET','https://raw.githubusercontent.com/Rajavasanthan/jsondata/master/pagenation.json',true);
request.send();
var personData;
var tbody,tbodytr,td1,td2,td3;
tbody = document.createElement('tbody');
request.onload = function(){
     personData = JSON.parse(this.response); 
    
     for(var j = 0;j< 10;j++){
        tbodytr = document.createElement('tr');
        td1 = createtrtd('td',personData[j].id);
        td2 = createtrtd('td',personData[j].name);
        td3 = createtrtd('td',personData[j].email);
        tbodytr.append(td1,td2,td3);
        tbody.append(tbodytr);
    }
     var button;
     var value;
     var buttonNext , buttonPrevious, buttonFirst, buttonLast;
     for(var i = 0;i < 10;i++){
        button = document.createElement('button');
        button.type = "button";
        button.setAttribute('class','button');
        button.innerHTML = i+1;
        button.value = i + 1;
        button.addEventListener("click",function(event){
            value = event.currentTarget.value  - 1;
            if (value === 9){
                buttonNext.disabled = true;
                buttonLast.disabled = true;
                buttonPrevious.disabled = false;
                buttonFirst.disabled = false;
            }
            if (value === 0){
                buttonPrevious.disabled = true;
                buttonNext.disabled = false;
                buttonFirst.disabled = true;;
            }
            if (value >= 1 && value <= 8 ){
                buttonNext.disabled = false;
                buttonPrevious.disabled = false;
                buttonFirst.disabled = false;
                buttonLast.disabled = false;
            }
            addData(personData, value);
          }, false);
        container.append(button);
     }
     
         buttonFirst = document.createElement('button');
        buttonFirst.type = "button";
        buttonFirst.setAttribute('class','button');
        buttonFirst.innerHTML = "First";
        buttonFirst.value = "First";
        buttonFirst.addEventListener("click",function(event){
           addData(personData, 0);  
        }, false);
        container.append( buttonFirst);

         buttonNext = document.createElement('button');
        buttonNext.type = "button";
        buttonNext.setAttribute('class','button');
        buttonNext.innerHTML = "Next";
        buttonNext.value = "Next";
        buttonNext.addEventListener("click",function(event){
            addData(personData, value+1);
            value = value + 1;
            buttonFirst.disabled = false;
            buttonPrevious.disabled = false;
            if(value == 9){
                buttonNext.disabled = true;
                buttonLast.disabled = true;
            }
        }, false);
        container.append(buttonNext);

         buttonPrevious = document.createElement('button');
        buttonPrevious .type = "button";
        buttonPrevious .setAttribute('class','button');
        buttonPrevious .innerHTML = "Previous";
        buttonPrevious .value = "Previous";
        buttonPrevious.addEventListener("click",function(event){
            addData(personData, value-1);
            value = value - 1;
            buttonNext.disabled = false;
            buttonLast.disabled = false;
           if(value == 0){
                buttonPrevious.disabled = true;
                buttonFirst.disabled = true;
            }
           
        }, false);
        container.append(buttonPrevious );

        var buttonLast = document.createElement('button');
        buttonLast.type = "button";
        buttonLast.setAttribute('class','button');
        buttonLast.innerHTML = "Last";
        buttonLast.value = "Last";
        buttonLast.addEventListener("click",function(event){
            addData(personData, 9);  
         }, false);
        container.append(buttonLast);
        
}

table.append(thead,tbody);
container.append(table);
document.body.append(container);


function createtrtd(elementname,value="",classname=""){
    var td = document.createElement(elementname);
    td.setAttribute('class','classname');
    td.innerHTML = value;
    return td;
}

function addData(personData, k){
    var tbl = document.querySelector('.table');
    for(var i = 1; i <=10; i++){
        tbl.deleteRow(1);
    } 
    
    for(var j = k*10;j < ((k*10)+10);j++){
        tbodytr = document.createElement('tr');
        td1 = createtrtd('td',personData[j].id);
        td2 = createtrtd('td',personData[j].name);
        td3 = createtrtd('td',personData[j].email);
        tbodytr.append(td1,td2,td3);
        tbody.append(tbodytr);
    }
}

