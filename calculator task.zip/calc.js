var val1 = "",val2 = "";

function getValue(obj) {
    val1 = val1 + obj.value; 
    //document.getElementById('input').value = val1; 
    document.getElementById('input').value = document.getElementById('input').value  + obj.value;
}

var opt = "";
var previous = "";
var next = "";

function operation(obj){

     opt = obj.value;
    previous = val1;
    document.getElementById('input').value = previous + ' ' + opt + ' ';
    val1 = " ";

}

function remove(){
    console.log('result');
    document.getElementById('output').value = "";
    document.getElementById('input').value = "";
}
function calculate(){
    next = val1;
       val1 = "";
   var result;
 switch(opt){
     case '+' :        
       result = parseFloat(previous) + parseFloat(next);
       break;      
    case '-' :        
       result = parseFloat(previous) - parseFloat(next);
       break;         
    case 'x' :        
       result = parseFloat(previous) * parseFloat(next);
       break;   
    case '/' :        
       result = parseFloat(previous) / parseFloat(next);    
 }
 document.getElementById('output').value = result;
}

